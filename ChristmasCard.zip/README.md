# ChristmasCard
Simple Christmas card created for a friend using SDL1.2 and C++
